console.log("hello guys")

let input1 = document.getElementById('firstname')
console.log(input1.value)

let inputDOM = document.getElementsByClassName('input')
console.log(inputDOM)
for (let i=0; i<inputDOM.length;i++){
    console.log(inputDOM[i].value)
}
let fnDOM = document.querySelector('#firstname')
console.log(fnDOM.value)
let fnDOM2 = document.querySelector('.input') // can be use with #id .class or input[name=___]
console.log(fnDOM2.value)

 let checkboxstatus = document.querySelectorAll('input[name=interest]')
 for(let i=0;i<checkboxstatus.length; i++){
    console.log(checkboxstatus[i].value)
 }
 function userclicked(){
    console.log("clicked")
 }
 function divclick(){
    console.log("toiletv1") /* can be used with div */
 }
function genchange(){
    console.log('gencha')
    let genderinp = document.querySelectorAll('input[name=gender]')
    let gender =""
    for(let i=0; i < genderinp.length; i++){
        if(genderinp[i].checked){
            gender = genderinp[i].value
        }
    }
    console.log('selected gender:',gender)
}

function but1click(){
    console.log("click1")
}

let but2dom = document.getElementById('but2')
but2dom.addEventListener('click',  function(){
    console.log('but2clck')
}
)

let helodom = document.getElementById('txttest')
console.log(helodom.textContent)
console.log(helodom.innerText)
console.log(helodom.innerHTML)
helodom.innerText = "hello" // จาก output เห็นว่าเปลี่ยนยัน html
console.log(helodom.textContent)
console.log(helodom.innerText)
console.log(helodom.innerHTML)
helodom.innerText = "hello<b>oo<b>" // doesnt work
console.log(helodom.textContent)
console.log(helodom.innerText)
console.log(helodom.innerHTML)
helodom.innerHTML = "hello<b>oo<b>" // oo is bold
console.log(helodom.textContent)
console.log(helodom.innerText)
console.log(helodom.innerHTML)

//แก้ค่าinnerHTML
function subint2(){
    let interest2 = document.querySelectorAll('input[name = interestv2]')
    let contentdom = document.getElementById('content2')
    let contentHMTL = '<ul>'
    for( let i=0;i<interest2.length;i++){
        if(interest2[i].checked){
            //console.log(interest2[i].value)
            contentHMTL += "<li>"+interest2[i].value + "</li>"
        }
    }
    contentHMTL += '</ul>'
    contentdom.innerHTML = contentHMTL
}

let linkmod  = document.getElementById('link1')
console.log(linkmod.getAttribute('href'))
linkmod.setAttribute('href','https://github.com') // now redirected to github
let but3 = document.getElementById('submit3')
but3.addEventListener('click', function(){
    but3.setAttribute('disabled','true')
    but3.style.borderColor = 'red' // css atrtribute changeg
})



/*
keydown/keypress input จะ delay ถ้าอยากได้ปจบใช้ keyup
mouse over = hover
mousedown = กดอยู่
mouseup = ปล่อย
.inner text = userเห็น
.textconent = ทั้งหมด
.innerHTML = มาทั้งบรรทัด
*/ 